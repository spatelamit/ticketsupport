<?php  

class MyCompany_MyModule_Block_Adminhtml_MyModulebackend extends Mage_Adminhtml_Block_Template {

}